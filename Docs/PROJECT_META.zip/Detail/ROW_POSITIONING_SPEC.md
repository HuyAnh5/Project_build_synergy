# ROW_POSITIONING_SPEC.md

> File này là spec riêng cho **front row / back row**.
> Chỉ ghi lại **logic của row**:
> - row là gì,
> - rule target chuẩn là gì,
> - rule AoE chuẩn là gì,
> - row áp dụng cho phe nào,
> - row được content đọc như thế nào,
> - row tách với lane/order ra sao.
>
> File này **không** ghi flow/control grammar, lane sequencing, hay damage modifier ngoài row.


> **CURRENT SOURCE UPDATE:** Access Type hiện tại chỉ dùng **Melee** và **Range**. `Strike` là thuật ngữ cũ cho access type và không còn dùng làm source.

---
---

## 1. Row là gì

**Front Row / Back Row** là lớp:

- vị trí
- quyền target
- combat state

Row **không phải** lớp cộng/trừ damage mặc định.

Row tự thân **không có thưởng/phạt nội tại**.
Nó chỉ là:

- điều kiện để dùng skill nào
- điều kiện để target ai là hợp lệ
- combat state để skill/relic/content khác đọc nếu muốn

Không có rule nền kiểu:

- front row luôn tăng damage
- back row luôn giảm damage nhận
- front row luôn tank hơn bằng modifier ẩn
- back row luôn yếu hơn bằng modifier ẩn

Mọi payoff kiểu:

- đang ở `Front Row` thì `+ Added Value`
- đang ở `Back Row` thì nhận Guard
- đổi row thì proc effect

đều phải đến từ `skill / relic / content` viết rõ ra, không phải từ bản thân row.

Rule này áp dụng **đối xứng cho cả 2 phe**:

- player team
- enemy team

Sau này nếu player có ally thì ally cũng dùng đúng rule row này.

---

## 2. Tách thành 2 lớp riêng

Row system nên được đọc qua **2 lớp riêng**:

### 2.1 Access Type

- `Melee`
- `Range`

### 2.2 Delivery Pattern

- `Single Target`
- `Row AoE`
- `All-row / Cross-row`

`All-row / Cross-row` là **ngoại lệ hiếm**, không phải mặc định.

---

## 3. Rule target chuẩn

### 3.0 Rule dùng skill theo row

- Bắt đầu mỗi combat, player luôn ở `Front Row`.
- `Melee` chỉ dùng được khi caster đang ở `Front Row`.
- Nếu caster đang ở `Back Row`, caster không được dùng `Melee`.
- `Range` dùng được ở cả `Front Row` lẫn `Back Row`.

Nói ngắn:

- `Front Row` mở quyền dùng melee
- `Back Row` không tự có penalty khác ngoài việc không dùng được melee
- `Range` không bị khóa bởi row của caster

### 3.1 Melee

Nếu phe đối diện vẫn còn ít nhất 1 unit sống ở **front row**:

- không được target **back row**

Chỉ khi **front row trống hết**:

- mới được target **back row**

Rule rất quan trọng:

- việc attacker đang đứng **front** hay **back** không tự mở quyền đánh xuyên row,
- thứ quyết định quyền chạm mục tiêu là **Access Type**,
- với `Melee`, front row luôn là lớp chặn mặc định.

Nói gọn:

- **Melee luôn bị front row chặn**

### 3.2 Range

`Range` có thể target tự do:

- front row
- back row

`Range` không bị front row chặn như `Melee`.

---

## 4. Rule AoE chuẩn

### 4.1 Melee AoE

Nếu phe đối diện còn unit sống ở **front row**:

- chỉ quét được **front row**

Chỉ khi **front row trống**:

- mới quét được **back row**

Nói gọn:

- `Melee AoE` quét hàng ngoài cùng còn đang chặn.

### 4.2 Range AoE

`Range AoE` được chọn tự do **1 row** để quét:

- front
- hoặc back

### 4.3 Cross-row / All-row AoE

Đây là **ngoại lệ hiếm có chủ đích**.

Loại này có thể:

- chạm cả 2 row,
- hoặc vượt luật chặn row thông thường.

Dành cho các case đặc biệt như:

- vài skill hiếm của player,
- vài đòn boss,
- các ngoại lệ kiểu `Lightning / Mark`.

---

## 5. Điều rất quan trọng cần hiểu đúng

Câu đúng là:

**Nếu phe đối diện còn front row thì đòn kiểu Melee không thể đánh vào back row, bất kể người đánh đang đứng front hay back.**

Điều này có nghĩa:

- vị trí của attacker **không** tự mở quyền đánh xuyên row,
- đứng back row không làm `Melee` thành `Range`,
- đứng front row cũng không cho đặc quyền vượt row.

Thứ quyết định quyền target là:

1. `Access Type`
2. formation hiện tại của phe đối diện
3. delivery pattern
4. exception đặc biệt nếu có

Không phải:

- attacker đang đứng hàng nào

---

## 6. Áp dụng cho cả 2 phe

Rule row là rule dùng chung cho toàn combat, không phải rule riêng của enemy side.

### 6.1 Player side

Player có thể có:

- `Single Target`
- `Row AoE`
- `Cross-row`

Sau này ally của player cũng đọc row theo cùng hệ rule đó.

### 6.2 Enemy side

Enemy cũng dùng rule y hệt:

- có thể có `Single Target`
- có thể có `Row AoE`
- có thể có move hiếm kiểu `Cross-row`

Không có chuyện:

- row chỉ là rule để player target enemy,
- hoặc row chỉ là rule của enemy formation mà không áp lại cho player team.

### 6.3 Rule di chuyển row

Row không phải free toggle.
Một unit chỉ đổi row theo 3 nhóm rule:

1. **Dùng skill có effect đổi row**
2. **Bị skill của unit khác cưỡng ép đổi row**
3. **Auto formation shift** khi front row của phe đó trống hết

#### 6.3.1 Player side

- Player chỉ được đổi row thông qua skill.
- Ngoại lệ duy nhất là khi player đang ở `Back Row` và toàn bộ frontline/ally phía trước chết hết, player sẽ tự được đẩy lên `Front Row`.
- Nếu player đang ở `Back Row`, skill `Range + move to Front` vẫn dùng bình thường vì nó là `Range`.

#### 6.3.2 Enemy voluntary move

Nếu enemy **tự muốn** đổi row theo AI của chính nó, dù là:

- tiến lên `Front Row`
- hay lùi xuống `Back Row`

thì đều phải **tốn 1 turn riêng**.

Turn đó intent phải hiển thị rõ là:

- đang chuẩn bị lên `Front Row`
- hoặc đang chuẩn bị xuống `Back Row`

Đến đúng turn của nó thì enemy mới thực hiện hành động đổi row.
Turn move này không tự kèm thêm đòn đánh khác, trừ khi việc đổi row là effect đã được viết sẵn trong skill.

Ví dụ:

- enemy đang ở `Back Row` nhưng build/intent là melee thì intent hiển thị là sẽ tiến lên `Front Row`
- enemy đang bị đẩy lên `Front Row` do formation shift nhưng muốn lùi lại, thì nó cũng phải báo intent trước rồi tới turn của nó mới lùi xuống

#### 6.3.3 Auto formation shift

Nếu toàn bộ unit sống ở `Front Row` của một phe chết hết:

- các unit còn sống ở `Back Row` được đẩy lên `Front Row` ngay lập tức
- việc đẩy lên này **không tốn turn**
- đây là rule sửa formation tự động, không phải action

Ví dụ:

- có `3 enemy`: `1` đứa ở `Front Row`, `2` đứa ở `Back Row`
- đứa ở front chết
- `2` đứa ở back được đẩy lên `Front Row` ngay
- sau đó, nếu một đứa muốn lùi xuống lại `Back Row`, nó vẫn phải hiện intent rồi tốn đúng `1 turn` để lùi

#### 6.3.4 Điều kiện hợp lệ để lùi xuống Back Row

Một unit chỉ được tự lùi xuống `Back Row` nếu sau khi lùi:

- phe của nó vẫn còn ít nhất `1` unit khác đứng ở `Front Row`

Nói ngắn:

- không được để cả phe chủ động bỏ trống `Front Row`
- `Back Row` chỉ tồn tại khi phía trước vẫn còn ít nhất một người che chắn hợp lệ

---

## 7. Row có thể được đọc bởi content

Ngoài target legality nền, row còn là một **combat state** để content đọc.

Row có thể được dùng bởi:

- skill
- relic
- consumable
- enemy move
- boss move

Ví dụ các kiểu đọc hợp lệ:

- tăng sức mạnh nếu đang ở `Front Row`
- tăng sức mạnh nếu đang ở `Back Row`
- mở payoff nếu target đang ở một row cụ thể
- đổi vị trí của bản thân
- đổi vị trí đồng minh
- kéo enemy đổi hàng

Nói cách khác:

- row không tự sinh payoff,
- row chỉ cung cấp state vị trí để content đọc,
- payoff thật sự phải đến từ content viết rõ.

---

## 8. Ý nghĩa thiết kế

Row trả lời:

- **đánh được ai**

Access Type trả lời:

- **đòn này có bị front row chặn hay không**

Delivery Pattern trả lời:

- **đánh 1 mục tiêu, 1 hàng, hay cả 2 hàng**

Lane / order là lớp khác và trả lời:

- **resolve theo thứ tự nào**

Vì vậy:

- không được trộn row với lane,
- không dùng lane để suy ra target access,
- không dùng row để thay thế sequencing logic.

---

## 9. Runtime / implementation guardrail

- Không hardcode row thành damage multiplier mặc định.
- Không tự gắn bonus/phạt nội tại vào `Front Row / Back Row` nếu content không viết rõ.
- Không biến player row thành free stance toggle nếu không có skill/relic/effect cho phép.
- Không để vị trí attacker tự quyết định quyền đánh xuyên row.
- Không gộp row logic vào lane logic.
- `Cross-row / All-row` phải là exception rõ ràng, không phải default.
- `Lightning / Mark` có thể là exception vượt row, nhưng không vì thế mà mọi AoE khác đều thành full-board.
- Khi sau này player có ally, phải tiếp tục dùng cùng rule row thay vì tạo luật riêng cho player team.

---

## 10. Tóm tắt cực ngắn

1. Row là lớp vị trí và quyền target, không phải damage modifier nền.
2. Rule này áp dụng đối xứng cho cả player team và enemy team.
3. Bản thân row không có thưởng/phạt nội tại; mọi bonus theo row phải đến từ content.
4. `Melee` chỉ dùng được từ `Front Row` và luôn bị front row chặn.
5. `Range` dùng được ở mọi row và target tự do front hoặc back.
6. `Melee AoE` quét row ngoài cùng còn đang chặn.
7. Auto formation shift khi front row chết hết là ngay lập tức, không tốn turn.
8. Voluntary reposition lên/xuống row theo AI đều tốn 1 turn riêng, trừ khi đến từ skill/effect cưỡng ép.
6. `Range AoE` chọn tự do 1 row để quét.
7. `Cross-row` là ngoại lệ hiếm có chủ đích.
8. Vị trí của attacker không tự mở quyền đánh xuyên row.
9. Row là lớp khác với lane/order.