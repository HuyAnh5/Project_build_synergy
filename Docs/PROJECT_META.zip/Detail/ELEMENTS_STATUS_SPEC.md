# ELEMENTS_STATUS_SPEC.md

> Tài liệu này là **source of truth cho 5 hệ chính, status/effect cốt lõi và ailment system**.  
> Nó mô tả identity, quy tắc kích hoạt, payoff, interaction, edge case và định hướng UX của từng hệ.


> **CURRENT SOURCE UPDATE:** Bản này đã nhập các rule hiện tại từ các draft cũ. Không dùng file `archived combat change draft` làm source nữa. Resource hiện tại là **AP**. Combat flow hiện tại là **Player Phase**: dice tự roll đầu phase → player reorder → click/drag skill vào target để cast ngay → dice chuyển used state → End Phase → Enemy Phase.

---
---

## 1. Mục tiêu của hệ thống

Element / status engine tồn tại để tạo ra:

- nhịp **setup → payoff**,
- khác biệt thật sự giữa các build,
- sequencing có ý nghĩa,
- board state dễ đọc,
- chiều sâu chiến thuật mà không cần quá nhiều damage button đơn lẻ.

Trong game này, status **không chỉ để thêm số**.  
Mỗi hệ phải kéo player sang kiểu quyết định khác nhau.

---

## 2. Phạm vi file này

File này bao gồm:

- Physical,
- Fire / Burn,
- Ice / Freeze / Chilled,
- Lightning / Mark,
- Blood / Bleed,
- Ailment system,
- Stagger ở cấp interaction với status,
- rule tiêu thụ / lan / proc phụ,
- priority và edge case giữa direct-hit và effect phụ.

---



## 3. Logic Flow

Phần này mô tả **đường đi logic chung của element / status engine**: state được đọc ở đâu, consume / payoff / apply xảy ra theo thứ tự nào, và board state được cập nhật ra sao cho action kế tiếp.

### 3.1 Flow chung của một action có liên quan tới status

`Read current target state`  
→ Xác định target đang có Burn / Freeze / Chilled / Mark / Bleed / Ailment gì  
→ Kiểm tra miễn nhiễm, exclusivity hoặc special interaction rule  
→ Resolve hit / damage trước theo combat core  
→ Resolve consume / payoff nếu skill có consume window  
→ Resolve apply status mới nếu còn hợp lệ  
→ Update target state để làm truth state cho action tiếp theo

### 3.2 Flow theo nhóm hệ

**Physical**  
→ Read die / crit state  
→ Resolve direct-hit / anti-Guard / decisive finish  
→ Không dựa vào resource status riêng để payoff

**Fire / Burn**  
→ Apply Burn hoặc đọc Burn stack đang có  
→ Nếu skill là spender: consume Burn theo rule của skill  
→ Chuyển Burn stack thành bonus damage / payoff  
→ Update target state sau consume / expire theo từng batch Burn

**Ice / Freeze / Chilled**  
→ Kiểm tra target đang Freeze / Chilled hay không  
→ Nếu hợp lệ: apply Freeze hoặc chuyển sang / khai thác Chilled window  
→ Resolve payoff Guard / AP / tempo nếu skill text có ghi  
→ Update target state sau action

**Lightning / Mark**  
→ Kiểm tra target có Mark hay không  
→ Resolve hit/effect vào mục tiêu chính  
→ Nếu skill text có payoff từ Mark: resolve payoff đó  
→ Nếu hit / skill hợp lệ phá Mark: remove Mark; baseline hiện tại là 1 hit hợp lệ phá Mark

**Blood / Bleed**  
→ Nếu skill dùng HP bản thân làm tài nguyên: trả HP cost / self-damage theo skill text  
→ Apply Bleed stack lên target hoặc đọc lượng Bleed hiện có  
→ Bleed tick ở đầu lượt target theo rule riêng của Bleed  
→ Một số Blood skill có thể hồi HP / sustain / convert Bleed thành giá trị khác nếu skill text ghi rõ

### 3.3 Flow ailment chung

`Attempt apply ailment`  
→ Xác định source là player hay enemy  
→ Tính chance theo rule ailment hiện hành  
→ Check immunity / exclusivity nếu có  
→ Nếu thành công: gắn ailment state lên target  
→ Nếu thất bại: không đổi board state  
→ State mới được resolve ở đúng timing window của ailment đó



## 3A. Current elemental payoff rule

Element payoff hiện tại là **skill-text driven**.

Không còn luật nền tự động kiểu:

- Fire direct damage hit vào Burn thì mọi skill Fire đều tự consume Burn,
- Ice direct damage hit vào Freeze/Chilled thì mọi skill Ice đều tự cho AP/Guard,
- Lightning hit vào Mark thì mọi skill Lightning đều auto proc theo cùng một cách.

Thay vào đó:

- skill nào apply status thì ghi rõ,
- skill nào consume / phá / khai thác status thì ghi rõ,
- lượng damage / AP / Guard / payoff từ status là thông số của skill đó,
- ở scope hiện tại, mỗi hệ chủ yếu tương tác với status của chính hệ đó,
- cross-element reaction là future design space, chưa phải locked rule.

## 4. Element Identity Overview

Đây là identity gameplay cấp hệ.  
Các payoff cụ thể vẫn theo rule **skill-text driven** ở mục `3A`: skill nào apply / consume / phá / khai thác status thì phải ghi rõ trong skill text.

| Hệ | Identity ngắn | Damage profile | Target profile | Tài nguyên / điểm tựa | Kiểu chơi chính |
|---|---|---|---|---|---|
| Fire | Burst đơn mục tiêu + Burn setup | Cao | Chủ yếu đơn mục tiêu | Burn stack | Dồn damage lớn vào một target quan trọng bằng apply / consume Burn |
| Ice | Control + lấy tài nguyên | Trung bình | Chủ yếu đơn mục tiêu | Freeze / Chilled | Bẻ nhịp enemy, rồi khai thác Freeze/Chill để lấy AP / Guard / Focus / dice control theo skill text |
| Lightning | Mark setup → AOE lan truyền | Thấp nếu đánh riêng lẻ | Mạnh khi có nhiều enemy / row | Mark | Gắn Mark lên target đúng, sau đó đánh vào Mark để lan damage/effect ra board |
| Blood | Risk/reward bằng HP | DoT / sustain / payoff dài hạn | Có thể đơn mục tiêu hoặc áp lực dài hạn | HP bản thân + Bleed stack | Dùng HP của player làm tài nguyên, gây DoT, rồi hồi lại HP hoặc chuyển hóa giá trị thông qua Blood effect |
| Physical | Ít setup, crit lớn, số to | Cao khi crit | Chủ yếu direct-hit đơn giản | Dice lớn + crit `x1.5` | Chơi thẳng, dễ hiểu: chọn đúng target, dùng dice lớn, crit để tạo burst damage |

### 4.1 Guardrail theo hệ

- **Fire** không nên là AOE chính. Fire phải nổi bật ở burst đơn mục tiêu và Burn payoff.
- **Ice** không cần damage cao. Ice mạnh vì control, tempo và tài nguyên phụ.
- **Lightning** nên yếu nếu không có Mark. Mark là lý do khiến Lightning biến thành AOE / propagation.
- **Blood** phải có rủi ro thật. Nếu hồi HP quá dễ, việc dùng HP bản thân sẽ không còn là cost.
- **Physical** là hệ dễ chơi / ít setup nhất. Nếu chỉ có `crit x1.5` thì hơi nông, nên về sau có thể gắn thêm synergy với Basic Attack, dice mặt cao hoặc clean finish.

### 4.2 Prototype scope note

Prototype hiện tại không bắt buộc phải bật đủ cả 5 hệ.  
Nếu chỉ đang test core combat, ưu tiên giữ **Fire / Ice / Lightning** trước. **Blood** và **Physical** có thể là future element hoặc content phase sau, trừ khi bản test cần kiểm tra trực tiếp identity của chúng.

## 5. Physical

### 5.1 Mục tiêu

Physical tồn tại để cho player một trục:

- burst rõ ràng,
- crit mạnh hơn hệ thường,
- số to + dice lớn + crit = damage to,
- anti-Guard,
- hit thẳng, ít vòng vo,
- cảm giác clean, decisive,
- ít phụ thuộc vào status setup.

### 5.2 Rule đã chốt

- Crit của Physical dùng **`+50% Base`** thay vì `+30% Base` như hệ thường. Có thể hiểu ở gameplay level là Physical crit gây khoảng **`x1.5` damage trên Base component**.

### 5.3 Ý nghĩa thiết kế

Physical không cần quá nhiều trang trí status để có identity.  
Hệ này mạnh ở:

- timing,
- lane order,
- read Guard,
- chọn đúng thời điểm dồn hit chính.

### 5.4 Edge cases / lưu ý

- Nếu skill Physical có tag `Sunder`, phải đọc thêm rule riêng của `Sunder`; không có hidden multiplier mặc định.
- Physical vẫn chịu rule Base/Added như mọi hệ khác; không được vì là hệ “đánh thẳng” mà cho condition đọc từ resolved value.

---

## 6. Fire / Burn

### 6.1 Mục tiêu

Fire là hệ của:

- setup tài nguyên,
- giữ lại trên mục tiêu,
- rồi consume đúng lúc để nổ burst.

Burn **không phải DoT chính**.  
Burn là **resource để consume**.

### 6.2 Rule đã chốt cho Burn

- Burn có stack.
- Mỗi lần apply Burn tạo ra **một batch Burn riêng** tồn tại **3 turn**.
- Tổng Burn hiển thị trên mục tiêu = **tổng mọi batch Burn còn sống**.
- Khi một batch Burn hết hạn, **chỉ batch đó biến mất**; các batch Burn apply sau vẫn còn.
- Burn **không tự bị consume bởi mọi Fire hit**.
- Chỉ skill ghi rõ `consume Burn` mới consume Burn.
- Damage / payoff khi consume Burn do chính skill quyết định: có thể là `0`, `1`, `2`, `3` damage mỗi Burn hoặc một hiệu ứng khác.
- Nếu skill không ghi consume Burn, Burn vẫn ở lại mục tiêu.

Ví dụ đúng rule:

- Turn 1: áp `7 Burn` -> mục tiêu hiện `7 Burn`
- Turn 3: áp thêm `9 Burn` -> mục tiêu hiện `16 Burn`
- Sang turn sau, batch `7 Burn` cũ hết hạn -> mục tiêu còn `9 Burn`, không mất sạch toàn bộ Burn

### 6.3 Identity gameplay

Burn tồn tại để tạo ra quyết định kiểu:

- nên bồi thêm stack hay kích nổ ngay,
- nên chia Burn lên nhiều mục tiêu hay dồn một mục tiêu,
- nên dùng lane đầu để tích Burn hay lane cuối để detonate,
- phải add Burn sớm và kích nổ sớm, nếu không batch Burn cũ sẽ rụng dần,
- nên ưu tiên exact-value / custom dice build để mở loop sâu hơn hay không.

### 6.4 Quan hệ với direct-hit

Burn consume được tính như **một phần của direct-hit** nếu nó nằm trong skill direct-hit.  
Vì vậy:

- nếu hit đó là hit direct tiếp theo sau Stagger,
- phần Burn consume trong hit đó được cộng vào tổng damage trước khi nhân `1.2`.

### 6.5 Điều Burn không nên trở thành

Burn không nên bị thiết kế thành “poison clone”.  
Nếu Fire chỉ còn là hệ gây DoT thụ động, nó sẽ mất bản sắc setup → payoff.

### 6.6 Edge cases

- UI chỉ cần hiển thị **tổng Burn stack**, không cần lộ tuổi thọ từng batch Burn ra cho player.
- Burn tiêu qua skill direct-hit được tính vào direct-hit đó.
- Burn consume không tự biến thành một effect riêng tách rời nếu text skill không nói vậy.
- Các relic tăng stack Burn phải cộng vào logic apply, không được âm thầm đổi baseline consume nếu text không ghi.
- Khi consume Burn, skill consume toàn bộ Burn **đang còn sống tại thời điểm đó**.

---

## 7. Ice / Freeze / Chilled

### 7.1 Mục tiêu

Ice là hệ của:

- tempo,
- control,
- tạo khoảng nghỉ,
- rồi mở cửa sổ payoff tài nguyên.

### 7.2 Rule đã chốt

- **Freeze**: skip 1 turn
- Hết Freeze → thành **Chilled**
- **Chilled tồn tại 2 turn**
- Đang Freeze hoặc Chilled thì miễn Freeze mới nếu skill không ghi ngoại lệ
- Ice không còn auto payoff cố định khi hit target Freeze/Chilled
- Skill nào cho `+AP`, `+Guard`, kéo dài Chilled hoặc khai thác Freeze/Chilled phải ghi rõ trong skill text

Ví dụ:

- một skill Ice có thể ghi: hit target Freeze/Chilled thì nhận `+1 AP`,
- skill khác có thể ghi: hit target Freeze/Chilled thì nhận `+3 Guard`,
- skill khác có thể không có payoff tài nguyên nào.

### 7.3 Identity gameplay

Ice không mạnh vì damage thô.  
Ice mạnh vì:

- bẻ nhịp combat,
- tạo tempo swing,
- cho player cơ hội đổi control thành tài nguyên,
- ép người chơi chọn đúng cửa sổ khai thác Chilled.

### 7.4 Freeze và Chilled không phải cùng một thứ

- **Freeze** là trạng thái CC chính.
- **Chilled** là trạng thái hậu Freeze, tồn tại như cửa sổ payoff / tempo window.

Điểm rất quan trọng:  
Game không muốn Ice chỉ là “stun kéo dài”.  
Transition `Freeze → Chilled` chính là nơi hệ này có chiều sâu.

### 7.5 Edge cases

- Không áp Freeze mới nếu mục tiêu đã Freeze hoặc Chilled.
- Ice không có reward nền cố định khi hit mục tiêu Freeze/Chilled.
- Nếu một skill Ice cho `+AP`, `+Guard`, kéo dài Chilled hoặc khai thác Freeze/Chilled, effect đó phải được ghi rõ trong skill text.

---

## 8. Lightning / Mark

### 8.1 Mục tiêu

Lightning là hệ của:

- board pressure,
- propagation,
- direct-hit đúng mục tiêu để lan ảnh hưởng ra cả board.

Mark là **weak point** để direct-hit khai thác.  
Mark **không stack**.

### 8.2 Rule đã chốt cho Mark

- Mark không stack.
- Mark không có thời hạn.
- Mark không tự hết theo turn.
- Mark tồn tại cho đến khi bị một hit / skill hợp lệ phá.
- Baseline hiện tại: **1 hit hợp lệ phá Mark**, trừ khi skill / relic ghi rõ khác.
- Shock phụ hoặc effect phụ không phá Mark nếu text không ghi rõ.

Ý nghĩa:

- Mark là weak point bền vững để player setup trước.
- Player không bị ép dùng Mark ngay trong cùng turn.
- Nhưng khi đã khai thác bằng hit hợp lệ, Mark thường bị phá để tránh payoff lặp vô hạn.

### 8.3 Hit vào Mark

Mark payoff hiện tại phải nằm trong skill text.

Baseline:

- Mark là weak point bền vững.
- Một hit hợp lệ có thể phá Mark.
- Hit / skill nào gây thêm damage, lan shock, tạo consumable hoặc hiệu ứng khác từ Mark phải ghi rõ trong text.
- Không còn mặc định mọi non-Lightning hit vào Mark đều +3 damage.

### 8.4 Lightning và Mark

Lightning vẫn là hệ chính hiện tại dùng Mark để tạo board pressure / propagation, nhưng payoff phải được ghi rõ trong skill.

Ví dụ skill Lightning có thể:

- hit mục tiêu có Mark rồi gây shock all enemies,
- spread Mark,
- phá Mark để tạo AP / damage / utility,
- giữ Mark nếu skill text nói rõ.

Không có auto payoff nền áp cho mọi skill Lightning nếu text skill không ghi.

### 8.5 Rule của shock phụ Lightning

Shock phụ phải giữ các rule sau:

- **không cộng Added Value**,
- **không tiêu Mark**,
- **không proc Mark**,
- **không chain tiếp**.

Shock phụ phải rõ ràng, gọn, không cascade vô hạn.

### 8.6 Nếu AoE Lightning direct-hit nhiều mục tiêu có Mark

Current locked rules:

- mỗi mục tiêu có Mark tạo **1 shock proc**,
- shock chạy **tuần tự**,
- mỗi proc cách nhau **`0.2s`**.

### 8.7 Identity gameplay

Lightning là hệ của:

- chọn đúng mục tiêu để cả board trả giá,
- ưu tiên sequencing và board setup,
- đổi direct-hit thành lan áp lực.

### 8.8 Edge cases

- Shock phụ không consume Mark.
- Shock phụ không tự proc Mark hoặc chain tiếp.
- Nếu AoE direct-hit nhiều target có Mark, tính từng proc shock tuần tự.
- Nếu hit không phải direct-hit thì không được coi là trigger Mark payoff kiểu hit chính.

---

## 9. Blood / Bleed

### 9.1 Mục tiêu

Blood là hệ của:

- risk/reward,
- dùng HP bản thân làm tài nguyên,
- damage-over-time thật thông qua Bleed,
- hồi lại HP / sustain nếu player khai thác đúng payoff,
- chuyển hóa tài nguyên ở build phù hợp.

Trong tài liệu này:

- **Blood** là identity / element fantasy,
- **Bleed** là status chính đại diện cho DoT và áp lực dài hạn.

### 9.2 Rule đã chốt cho Bleed

- Bleed gây damage **đầu lượt**
- Bleed **bỏ qua Guard**
- Bleed **giảm dần theo lượt**
- current wording rõ nhất hiện tại là **`-1 stack mỗi cuối lượt`**

### 9.3 Rule định hướng cho Blood

Các hiệu ứng Blood phải theo skill text, không có hidden rule mặc định.

- Skill nào tốn HP / self-damage phải ghi rõ lượng HP mất.
- Skill nào hồi HP phải ghi rõ điều kiện hồi và lượng hồi.
- Skill nào convert Bleed thành HP / Guard / Consumable / damage phải ghi rõ.
- Không mặc định mọi Blood skill đều hồi máu.
- Không mặc định mọi Bleed tick đều hồi máu.
- Không để Blood hồi HP dễ đến mức HP cost trở thành miễn phí.

### 9.4 Identity gameplay

Blood khác Burn ở chỗ:

- Burn là tài nguyên để consume burst,
- Bleed là damage-over-time thật,
- Blood dùng chính HP của player như một resource combat,
- Blood phải cho cảm giác player đang đánh đổi an toàn hiện tại để lấy tempo / sustain / payoff về sau.

Một turn Blood tốt nên tạo câu hỏi kiểu:

- có nên mất HP bây giờ để giết enemy nguy hiểm không,
- có đủ cơ hội hồi lại HP sau đó không,
- có nên kéo dài Bleed để tạo sustain không,
- có nên chấp nhận rủi ro HP thấp để đổi lấy damage / resource mạnh hơn không.

### 9.5 Edge cases

- Bleed tick **không consume Stagger**.
- Bleed bypass Guard nhưng vẫn phải đọc đúng timing đầu lượt.
- Bleed stack là một dạng tài nguyên build-level, không nên bị coi chỉ là số máu chảy máu vô danh.
- Blood self-damage không nên được tính như enemy damage nếu có hệ thống trigger “khi bị enemy đánh”, trừ khi skill / relic ghi rõ.
- Nếu Blood skill vừa gây self-damage vừa hồi HP, UI phải preview cả HP mất và HP hồi để player hiểu tradeoff thật.
## 10. Stagger như một payoff trung gian

Dù Stagger là core combat rule, ở cấp status engine nó đóng vai trò như một “cơ hội payoff ngắn hạn”.

Current locked rules nhắc lại:

- Khi Guard từ `> 0` về `0`, mục tiêu vào Stagger.
- Chỉ **hit direct kế tiếp duy nhất** mới ăn `x1.2 tổng damage`.
- `Lightning shock` và `Bleed tick` **không consume** Stagger.
- `Burn consume` nằm trong direct-hit thì tính vào tổng damage trước khi nhân `1.2`.

Ý nghĩa thiết kế:

- Stagger thưởng cho sequencing tốt,
- tạo cầu nối giữa anti-Guard và payoff,
- khiến Guard break có giá trị chiến thuật chứ không chỉ là mất giáp.

---

## 11. Ailment system

### 11.1 Vai trò hiện tại

Ailment hiện được coi là **enemy-side system**.

Nghĩa là:

- không xem ailment là fantasy trung tâm của player build ở giai đoạn hiện tại,
- enemy là bên chủ yếu dùng ailment lên player / combat state,
- nếu trong code còn helper player → enemy thì không nên xem đó là gameplay ưu tiên.

### 11.1b Player status và enemy dice debuff là 2 hệ riêng

Player-inflicted status và enemy-inflicted debuff không dùng chung một rule dù có thể cùng flavor nguyên tố.

- **Player → Enemy**: Burn / Freeze / Chilled / Mark là setup-payoff để player tạo lợi thế.
- **Enemy → Player**: Fire / Freeze / Electric themed debuff là dice/action disruption, ví dụ Burn lên dice khiến dùng dice mất HP, Freeze khóa dice, Electric giảm Base Value của một dice tạm thời, Blind che dice, hoặc disable Basic action.

Không được suy luận rằng vì Fire/Burn trên enemy hoạt động theo một cách thì Fire debuff lên player cũng phải giống hệt.

### 11.2 Rule chance hiện tại trong context

- **enemy → player = deterministic / 100% nếu intent đã telegraph hành động đó**.
- Đây không phải RNG punishment. Counterplay của player là đọc intent và lập kế hoạch: kill enemy trước, Guard, cleanse, dùng consumable, reorder dice, dùng dice bị ảnh hưởng trước, hoặc chấp nhận tradeoff.
- Enemy debuff mạnh không nên xuất hiện như surprise effect không báo trước.

### 11.3 Ý nghĩa thiết kế

Ailment tồn tại để:

- enemy tạo pressure,
- tạo disruption,
- thử thách cách player xoay resources và sequencing,
- nhưng không nên cướp vai trò trung tâm của dice loop.

### 11.4 Guardrail

Khi mô tả system, tooltip, refactor plan hoặc content note:

- không mô tả Ailment như bộ skill tiêu chuẩn player-side,
- không đẩy game thành một combat loop phụ chỉ xoay quanh ailment nếu chưa có chủ đích rõ,
- nếu sau này mở rộng ailment cho player, phải kiểm tra lại alignment với core pillars.

---

## 12. Priority và logic resolve tổng quát

### 12.1 Direct-hit phải được ưu tiên đọc rõ

Nhiều interaction trong game này chỉ đúng nếu action là **direct-hit**:

- Mark payoff,
- Burn consume nằm trong hit,
- Stagger consume,
- một số skill payoff theo exact value.

Vì vậy về mặt spec, luôn phải phân biệt:

- direct-hit,
- tick,
- proc phụ,
- shock,
- effect tồn đọng.

### 12.2 Setup → payoff phải nhìn ra được bằng mắt

Trong UI và design, player phải đọc ra được ít nhất:

- ai đang có Burn,
- ai đang có Mark,
- ai đang Freeze / Chilled,
- ai đang Bleed,
- ai đang Guard / Stagger.

Nếu board state quá khó đọc, status engine sẽ mất giá trị chiến thuật.

---

## 13. Những gì chưa final trong file này

Các vùng sau chưa nên coi là khóa cứng ở cấp content implementation:

- full catalog các ailment type cụ thể,
- icon / VFX / SFX cuối cùng cho từng trạng thái,
- tất cả rule phụ của mọi skill content pool,
- các exception quá đặc thù của từng boss hoặc từng enemy.

Nhưng các vùng sau là **current locked rules**:

- Burn là resource để consume; damage/effect khi consume do từng skill quyết định,
- Freeze → Chilled, miễn Freeze khi đang Freeze/Chilled, Ice payoff phải nằm trong skill text,
- Mark không stack, không có thời hạn, tồn tại cho đến khi hit/skill hợp lệ phá; Mark payoff phải nằm trong skill text,
- shock phụ không chain, không proc lại, không consume Mark,
- Blood dùng HP bản thân / hồi HP theo skill text; Bleed đầu lượt, bypass Guard, giảm dần, current wording `-1 stack mỗi cuối lượt`,
- ailment là enemy-side system; enemy debuff có thể deterministic/100% vì được telegraph qua enemy intent.

## Runtime Update Note (Archived)

Phần dưới đây là note runtime/implementation riêng cho ailment enemy-side. Nếu mâu thuẫn với các rule current locked phía trên, ưu tiên rule current locked.

### Enemy -> player dice ailment rules

- `Freeze` lên player:
  - chọn `1` viên dice mà player đang sở hữu trong loadout hiện tại,
  - effect này kéo dài `1 turn`,
  - viên dice đó vẫn được `reorder`,
  - nhưng không được dùng làm die source cho action trong thời gian effect còn tồn tại.
- `Burn` lên player:
  - chọn `1` viên dice mà player đang sở hữu trong loadout hiện tại,
  - effect này kéo dài `2 turn`,
  - viên dice đó vẫn được `reorder`,
  - nhưng nếu player dùng viên dice đó thì player mất HP theo rule của skill / effect nguồn.
- `Lightning` lên player:
  - effect này kéo dài `2 turn`,
  - giảm `-1 Base Value` trên **tất cả các mặt** của **tất cả các viên dice** player đang sở hữu,
  - đây là giảm trên profile mặt của die, không chỉ giảm kết quả roll của turn hiện tại.

### Rule loại trừ giữa Freeze và Burn

- Cả hai cùng bám vào `1 die cụ thể` của player.
- Một viên đang bị `Freeze` không được chọn để áp `Burn` cho tới khi `Freeze` hết.
- Một viên đang bị `Burn` không được chọn để áp `Freeze` cho tới khi `Burn` hết.
- Hai effect này không được chồng lên cùng `1` viên dice.

### Rule đọc UI / board state

Ngoài các status trên target / board, player cũng phải đọc được ít nhất:

- viên dice nào của mình đang bị `Freeze`,
- viên dice nào của mình đang bị `Burn`,
- player có đang bị `Lightning` debuff làm giảm `-1 Base Value` trên mọi mặt của toàn bộ dice hay không,
- và còn bao nhiêu turn tồn tại của từng effect này.
